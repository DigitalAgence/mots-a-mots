export function loader() {
  return new Response('<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><rect width="512" height="512" rx="110" fill="#583d50"/><path d="M118 148l130 18v195l-130-18zm146 18l130-18v195l-130 18z" fill="#f4e2de"/><circle cx="405" cy="395" r="23" fill="#b8856b"/></svg>', { headers: { 'Content-Type': 'image/svg+xml; charset=utf-8' } });
}
